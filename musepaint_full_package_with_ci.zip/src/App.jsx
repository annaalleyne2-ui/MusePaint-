import React, { useEffect, useRef, useState } from 'react'

const CANVAS_W = 1200
const CANVAS_H = 900

function uid(){ return Math.random().toString(36).slice(2) }

function emptyLayer(name='Layer'){ return { id: uid(), name, opacity:1, visible:true, history:[], redo:[] } }

function defaultPose(){ return ({ enabled:false, opacity:0.6, joints:{ head:{x:600,y:180}, neck:{x:600,y:220}, lShoulder:{x:560,y:245}, rShoulder:{x:640,y:245}, lElbow:{x:520,y:300}, rElbow:{x:680,y:300}, lHand:{x:500,y:360}, rHand:{x:700,y:360}, chest:{x:600,y:270}, pelvis:{x:600,y:340}, lKnee:{x:560,y:450}, rKnee:{x:640,y:450}, lFoot:{x:540,y:560}, rFoot:{x:660,y:560} } }) }

export default function App(){
  const [layers, setLayers] = useState([emptyLayer('Layer 1'), emptyLayer('Guide')])
  const [activeIdx, setActiveIdx] = useState(0)
  const [color, setColor] = useState('#111111')
  const [size, setSize] = useState(8)
  const [tool, setTool] = useState('brush')
  const [pose, setPose] = useState(defaultPose())

  const canvasesRef = useRef([])
  const overlayRef = useRef(null)
  const drawing = useRef(null)

  useEffect(()=>{ canvasesRef.current = canvasesRef.current.slice(0, layers.length) }, [layers.length])

  useEffect(()=>{
    const overlay = overlayRef.current; if(!overlay) return; overlay.width = CANVAS_W; overlay.height = CANVAS_H;
    function getRel(e){ const r=overlay.getBoundingClientRect(); return { x:(e.clientX-r.left)*(overlay.width/r.width), y:(e.clientY-r.top)*(overlay.height/r.height) } }
    function begin(e){ const idx=activeIdx; const cv=canvasesRef.current[idx]; if(!cv) return; const ctx=cv.getContext('2d'); drawing.current = { prev:getRel(e) }; const data=cv.toDataURL(); setLayers(ls=>{ const c=[...ls]; c[idx] = {...c[idx], history:[...c[idx].history, data].slice(-30), redo:[] }; return c }) }
    function move(e){ if(!drawing.current) return; const idx=activeIdx; const cv=canvasesRef.current[idx]; if(!cv) return; const ctx=cv.getContext('2d'); const from = drawing.current.prev; const to = getRel(e); ctx.strokeStyle = color; ctx.lineWidth = size; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(from.x, from.y); ctx.lineTo(to.x, to.y); ctx.stroke(); drawing.current.prev = to }
    function end(){ drawing.current = null }
    overlay.addEventListener('pointerdown', begin); window.addEventListener('pointermove', move); window.addEventListener('pointerup', end)
    return ()=>{ overlay.removeEventListener('pointerdown', begin); window.removeEventListener('pointermove', move); window.removeEventListener('pointerup', end) }
  }, [activeIdx, color, size, layers])

  function addLayer(){ setLayers(ls=>[...ls, emptyLayer(`Layer ${ls.length+1}`)]); setActiveIdx(layers.length) }
  function exportPNG(){ const out = document.createElement('canvas'); out.width=CANVAS_W; out.height=CANVAS_H; const o=out.getContext('2d'); o.fillStyle='#fff'; o.fillRect(0,0,out.width,out.height); for(let i=0;i<layers.length;i++){ if(!layers[i].visible) continue; o.globalAlpha = layers[i].opacity; o.drawImage(canvasesRef.current[i],0,0) } const a=document.createElement('a'); a.href = out.toDataURL('image/png'); a.download = 'musepaint.png'; a.click() }

  return (
    <div style={{height:'100vh', display:'flex', flexDirection:'column'}}>
      <div style={{padding:12, display:'flex', gap:8, alignItems:'center', background:'#fff', borderBottom:'1px solid #e5e7eb'}}>
        <img src='/musepaint_logo.png' alt='logo' style={{width:48,height:48}} />
        <div style={{fontWeight:700}}>Muse Paint</div>
        <div style={{marginLeft:'auto', display:'flex', gap:8}}>
          <button onClick={exportPNG}>Export PNG</button>
        </div>
      </div>
      <div style={{flex:1, display:'flex', gap:12, padding:12}}>
        <div style={{width:220, background:'#fff', padding:12, borderRadius:12}}>
          <div style={{fontWeight:600}}>Tools</div>
          <div style={{display:'flex', gap:8, marginTop:8}}>
            <button onClick={()=>setTool('brush')} style={{background: tool==='brush' ? '#111827':undefined, color: tool==='brush' ? '#fff':undefined}}>Brush</button>
            <button onClick={()=>setTool('smudge')} style={{background: tool==='smudge' ? '#111827':undefined, color: tool==='smudge' ? '#fff':undefined}}>Smudge</button>
            <button onClick={()=>setTool('eraser')} style={{background: tool==='eraser' ? '#111827':undefined, color: tool==='eraser' ? '#fff':undefined}}>Eraser</button>
          </div>
          <div style={{marginTop:12}}>Color<input type='color' value={color} onChange={e=>setColor(e.target.value)} /></div>
          <div style={{marginTop:8}}>Size<input type='range' min={1} max={80} value={size} onChange={e=>setSize(parseInt(e.target.value))} /></div>
          <div style={{marginTop:12}}>
            <div style={{fontWeight:600}}>Pose Studio</div>
            <label><input type='checkbox' checked={pose.enabled} onChange={e=>setPose(p=>({...p, enabled:e.target.checked}))} /> Enable 2D Pose</label>
            <button onClick={()=>setPose(defaultPose())}>Reset Pose</button>
          </div>
        </div>

        <div style={{flex:1, background:'#fff', borderRadius:12, display:'flex', justifyContent:'center', alignItems:'center'}}>
          <div style={{position:'relative', width:CANVAS_W, height:CANVAS_H}} className='canvas-wrap'>
            {layers.map((layer, i)=>(
              <canvas key={layer.id} ref={el=>canvasesRef.current[i]=el} width={CANVAS_W} height={CANVAS_H} style={{position:'absolute', left:0, top:0, opacity: layer.visible?layer.opacity:0}} />
            ))}
            <canvas ref={overlayRef} style={{position:'absolute', left:0, top:0, width:CANVAS_W, height:CANVAS_H, touchAction:'none'}} />
          </div>
        </div>

        <div style={{width:280, background:'#fff', padding:12, borderRadius:12}}>
          <div style={{fontWeight:600}}>Layers</div>
          <div style={{marginTop:8, display:'flex', flexDirection:'column', gap:8}}>
            {layers.map((layer,i)=>(
              <div key={layer.id} style={{display:'flex', gap:8, alignItems:'center'}}>
                <input type='checkbox' checked={layer.visible} onChange={e=>setLayers(ls=>{ const c=[...ls]; c[i]={...c[i], visible:e.target.checked}; return c })} />
                <input value={layer.name} onChange={e=>setLayers(ls=>{ const c=[...ls]; c[i]={...c[i], name:e.target.value}; return c })} style={{flex:1}} />
                <button onClick={()=>setActiveIdx(i)} style={{background: activeIdx===i? '#111827':'#e5e7eb', color: activeIdx===i? '#fff': '#111827'}}>Use</button>
              </div>
            ))}
            <div style={{display:'flex', gap:8, marginTop:8}}>
              <button onClick={()=>setLayers(ls=>[...ls, emptyLayer(`Layer ${ls.length+1}`)])}>+ Add Layer</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
